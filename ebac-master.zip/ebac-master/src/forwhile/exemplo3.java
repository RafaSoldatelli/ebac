package forwhile;

public class exemplo3 {
    public static void main(String args[]) {
        int count = 0;
        while(count < 2) {
            System.out.println("Repetição nr: " + count);
            count++;
        }
    }
}
