package atividades.modulo13;

public class Pessoa {
    private String nome;

    public Pessoa(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public String SetNome(String nome) {
        return this.nome = nome;
    }
}
